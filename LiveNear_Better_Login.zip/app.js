const form = document.getElementById("signupForm");
const message = document.getElementById("message");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const user = {
    firstName: document.getElementById("firstName").value,
    familyName: document.getElementById("familyName").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
    sex: document.getElementById("sex").value,
    postalCode: document.getElementById("postalCode").value,
    genre: document.getElementById("genre").value,
    createdAt: new Date().toISOString()
  };

  const users = JSON.parse(localStorage.getItem("liveNearUsers")) || [];
  users.push(user);
  localStorage.setItem("liveNearUsers", JSON.stringify(users));

  message.style.display = "block";
  form.reset();

  console.log("LiveNear users:", users);
});
